
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
import matplotlib.animation as animation
from scipy.spatial.distance import euclidean

def simulate_diffusion(positions, cell_radius, max_steps):
    history = [positions.copy()]
    
    for step in range(max_steps):
        new_positions = positions + np.random.normal(0, 0.3, positions.shape)
        
        for i in range(len(new_positions)):
            distance_from_center = euclidean(new_positions[i], [0, 0])
            
            if distance_from_center >= cell_radius:
                direction_to_center = -new_positions[i] / distance_from_center
                new_positions[i] = new_positions[i] + direction_to_center * 0.5
        
        positions = new_positions
        history.append(positions.copy())
    
    return history

if __name__ == "__main__":
    cell_radius = 10.0
    n_molecules = 20
    positions = np.random.uniform(-2, 2, (n_molecules, 2))
    history = simulate_diffusion(positions, cell_radius, 100)
    print("شبیه‌سازی کامل شد!")
